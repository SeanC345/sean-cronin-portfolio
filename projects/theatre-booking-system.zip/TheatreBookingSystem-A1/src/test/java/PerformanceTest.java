import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import com.example.theatrebookingsystema1.Performance;
import com.example.theatrebookingsystema1.Show;

import java.time.LocalDate;
import java.time.LocalTime;

import static org.junit.jupiter.api.Assertions.*;

public class PerformanceTest {
    private Performance performance;
    private Show show;

    @BeforeEach
    public void setUp() {
        show = new Show("Sample Show", 120, LocalDate.now(), LocalDate.now().plusDays(30), 10.0, 15.0, 20.0);
        performance = new Performance(LocalDate.now(), show, LocalTime.of(19, 0));
    }

    @Test
    public void testPerformanceCreation() {
        assertEquals(show, performance.getShow());
        assertEquals(LocalDate.now(), performance.getDate());
        assertEquals(LocalTime.of(19, 0), performance.getTime());
    }
}

