import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import com.example.theatrebookingsystema1.Booking;
import com.example.theatrebookingsystema1.Customer;
import com.example.theatrebookingsystema1.Performance;
import com.example.theatrebookingsystema1.Seat;
import com.example.theatrebookingsystema1.Show;
import com.example.theatrebookingsystema1.CustomLinkedList;

import java.time.LocalDate;
import java.time.LocalTime;

import static org.junit.jupiter.api.Assertions.*;

public class BookingTest {
    private Booking booking;
    private Customer customer;
    private Performance performance;
    private Show show;
    private CustomLinkedList<Seat> seats;

    @BeforeEach
    public void setUp() {
        show = new Show("Sample Show", 120, LocalDate.now(), LocalDate.now().plusDays(30), 10.0, 15.0, 20.0);
        performance = new Performance(LocalDate.now(), show, LocalTime.of(19, 0));
        customer = new Customer("John Doe", "john@example.com", "1234567890");
        seats = new CustomLinkedList<>();
        seats.add(new Seat(1));
        booking = new Booking(show, customer, performance, seats);
    }

    @Test
    public void testBookingCreation() {
        assertEquals("Sample Show", booking.getShow().getTitle());
        assertEquals("John Doe", booking.getCustomer().getName());
        assertEquals(1, booking.getBookedSeats().size());
    }
}
