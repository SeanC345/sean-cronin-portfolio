import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import com.example.theatrebookingsystema1.CustomLinkedList;

import static org.junit.jupiter.api.Assertions.*;

public class CustomLinkedListTest {
    private CustomLinkedList<String> list;

    @BeforeEach
    public void setUp() {
        list = new CustomLinkedList<>();
    }

    @Test
    public void testAdd() {
        list.add("Item1");
        assertEquals(1, list.size()); // List should have one item
    }

    @Test
    public void testRemove() {
        list.add("Item1");
        list.remove("Item1");
        assertEquals(0, list.size()); // List should be empty
    }
}