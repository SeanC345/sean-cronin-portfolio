import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import com.example.theatrebookingsystema1.SeatingArrangement;
import com.example.theatrebookingsystema1.Seat;

import static org.junit.jupiter.api.Assertions.*;

public class SeatingArrangementTest {
    private SeatingArrangement seatingArrangement;

    @BeforeEach
    public void setUp() {
        seatingArrangement = new SeatingArrangement(10, 10); // Assuming a 10x10 layout for this test
    }

    @Test
    public void testInitializeSeating() {
        Seat seat = seatingArrangement.getSeat(0, 0); // Accessing seat at (0, 0)
        assertNotNull(seat, "Seat should not be null");
        assertEquals(1, seat.getSeatNumber(), "First seat should have seat number 1");
    }

    @Test
    public void testBookSeat() {
        boolean booked = seatingArrangement.bookSeat(0, 0);
        assertTrue(booked, "Booking should be successful");
        assertTrue(seatingArrangement.getSeat(0, 0).isBooked(), "Seat at (0, 0) should be marked as booked");
    }
}


