import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import com.example.theatrebookingsystema1.Seat;

import static org.junit.jupiter.api.Assertions.*;

public class SeatTest {
    private Seat seat;

    @BeforeEach
    public void setUp() {
        seat = new Seat(1);
    }

    @Test
    public void testSeatCreation() {
        assertEquals(1, seat.getSeatNumber());
        assertFalse(seat.isBooked());
    }

    @Test
    public void testSeatBooking() {
        seat.bookSeat();
        assertTrue(seat.isBooked());
    }
}

