import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import com.example.theatrebookingsystema1.Show;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

public class ShowTest {
    private Show show;

    @BeforeEach
    public void setUp() {
        show = new Show("Sample Show", 120, LocalDate.now(), LocalDate.now().plusDays(30), 10.0, 15.0, 20.0);
    }

    @Test
    public void testShowCreation() {
        assertEquals("Sample Show", show.getTitle());
        assertEquals(120, show.getRunningTime());
        assertEquals(10.0, show.getStallPrice());
        assertEquals(15.0, show.getCirclePrice());
        assertEquals(20.0, show.getBalconyPrice());
    }
}

