module com.example.theatrebookingsystema1 {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.controlsfx.controls;

    opens com.example.theatrebookingsystema1 to javafx.fxml;
    exports com.example.theatrebookingsystema1;
}