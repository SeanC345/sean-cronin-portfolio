package com.example.theatrebookingsystema1;

import java.io.Serializable;

public class Seat implements Serializable {
    private int seatNumber;
    private boolean booked;
    private static final long serialVersionUID = 1L; // Version control for serialization

    public Seat(int seatNumber) {
        this.seatNumber = seatNumber;
        this.booked = false;
    }

    public boolean isBooked() {
        return booked;
    }

    public int getSeatNumber(){
        return seatNumber;
    }

    public void bookSeat() {
        this.booked = true;
    }



    @Override
    public String toString() {
        return booked ? "Booked" : "Seat " + seatNumber;
    }
}
