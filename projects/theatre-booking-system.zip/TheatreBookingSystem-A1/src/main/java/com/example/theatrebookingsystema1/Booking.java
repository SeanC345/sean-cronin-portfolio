package com.example.theatrebookingsystema1;

import java.io.Serializable;

public class Booking implements Serializable {
    private Show show;            // The show the customer is booking
    private Customer customer;    // The customer making the booking
    private Performance performance; // The performance being booked
    private CustomLinkedList<Seat> bookedSeats; // List of booked seats for this booking
    private static final long serialVersionUID = 1L; // Version control for serialization
    private static int bookingCounter = 1; // Static counter shared across all Booking instances
    private String bookingId;

    // Constructor to create a booking with the specified show, customer, performance, and booked seats
    public Booking(Show show, Customer customer, Performance performance, CustomLinkedList<Seat> bookedSeats) {
        this.bookingId = "B" + (bookingCounter++);
        this.show = show; // Set the show for this booking
        this.customer = customer; // Set the customer making the booking
        this.performance = performance; // Set the performance details for the booking
        this.bookedSeats = bookedSeats; // Set the list of booked seats
    }

    // Getter method to get the show associated with this booking
    public Show getShow() {
        return show; // Return the show
    }

    public String getBookingId() {
        return bookingId;
    }

    // Getter method to get the customer associated with this booking
    public Customer getCustomer() {
        return customer; // Return the customer
    }

    // Getter method to get the performance associated with this booking
    public Performance getPerformance() {
        return performance; // Return the performance
    }

    // Getter method to get the list of booked seats
    public CustomLinkedList<Seat> getBookedSeats() {
        return bookedSeats; // Return the list of booked seats
    }

    public double getTotalPrice() {
        double totalPrice = 0.0;

        CustomLinkedList.Node<Seat> currentSeatNode = bookedSeats.getHead();
        while (currentSeatNode != null) {
            Seat seat = currentSeatNode.data;
            int seatNumber = seat.getSeatNumber();

            // Determine the section price based on seat number ranges
            if (seatNumber >= 1 && seatNumber <= 24) {  // Balcony section
                totalPrice += performance.getShow().getBalconyPrice();
            } else if (seatNumber >= 25 && seatNumber <= 54) {  // Circle section
                totalPrice += performance.getShow().getCirclePrice();
            } else if (seatNumber >= 55 && seatNumber <= 94) {  // Stall section
                totalPrice += performance.getShow().getStallPrice();
            }

            currentSeatNode = currentSeatNode.next;
        }

        return totalPrice;
    }






    // Method to display the booking information as a string
    @Override
    public String toString() {
        return String.format(
                "Booking ID: %s\n" +
                        "Show: %s\n" +
                        "Customer: %s\n" +
                        "Performance Date: %s\n" +
                        "Performance Time: %s\n" +
                        "Seats Booked: %d\n" +
                        "Seat Numbers: %s",
                bookingId,                              // Include Booking ID
                show.getTitle(),                        // Show title
                customer.getName(),                     // Customer name
                performance.getDate(),                  // Performance date
                performance.getTime(),                  // Performance time
                bookedSeats.size(),                     // Number of seats booked
                bookedSeats.toString()                  // Display seat numbers
        );
    }

}

