package com.example.theatrebookingsystema1;
import java.io.Serializable;
import java.time.LocalDate;

public class Show implements Serializable {
    private String title; // The title of the show
    private int runningTime; // The duration of the show in minutes
    private LocalDate startDate; // The date the show starts
    private LocalDate endDate; // The date the show ends
    private double stallPrice; // The price of tickets in the stall section
    private double circlePrice; // The price of tickets in the circle section
    private double balconyPrice; // The price of tickets in the balcony section
    private static final long serialVersionUID = 1L; // Version control for serialization

    // Constructor to create a new show with the specified details
    public Show(String title, int runningTime, LocalDate startDate, LocalDate endDate,
                double stallPrice, double circlePrice, double balconyPrice) {
        this.title = title; // Set the title of the show
        this.runningTime = runningTime; // Set the running time of the show
        this.startDate = startDate; // Set the start date of the show
        this.endDate = endDate; // Set the end date of the show
        this.stallPrice = stallPrice; // Set the price for stall tickets
        this.circlePrice = circlePrice; // Set the price for circle tickets
        this.balconyPrice = balconyPrice; // Set the price for balcony tickets
    }

    // Method to get the title of the show
    public String getTitle() {
        return title;
    }

    // Method to get the running time of the show
    public int getRunningTime() {
        return runningTime;
    }

    // Method to get the start date of the show
    public LocalDate getStartDate() {
        return startDate;
    }

    // Method to get the end date of the show
    public LocalDate getEndDate() {
        return endDate;
    }

    // Method to get the price of stall tickets
    public double getStallPrice() {
        return stallPrice;
    }

    // Method to get the price of circle tickets
    public double getCirclePrice() {
        return circlePrice;
    }

    // Method to get the price of balcony tickets
    public double getBalconyPrice() {
        return balconyPrice;
    }

    // Method that returns a string representation of the show (just the title)
    @Override
    public String toString() {
        return String.format(
                "Show: %s\nRunning Time: %d minutes\nDates: %s to %s\nTicket Prices - Stall: $%.2f, Circle: $%.2f, Balcony: $%.2f",
                title,
                runningTime,
                startDate,
                endDate,
                stallPrice,
                circlePrice,
                balconyPrice
        );
    }


    // Method to check if two shows are equal based on their titles
    @Override
    public boolean equals(Object o) {
        if (this == o) return true; // Check if the same object
        if (o == null || getClass() != o.getClass()) return false; // Check for null or different class
        Show show = (Show) o; // Cast to Show type
        return title.equals(show.title); // Compare titles for equality
    }
}
