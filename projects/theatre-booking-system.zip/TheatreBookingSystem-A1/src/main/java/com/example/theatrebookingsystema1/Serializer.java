package com.example.theatrebookingsystema1;

import java.io.*; // Importing classes for input/output operations

public class Serializer<T> {
    private String filename; // The name of the file to save/load data

    // Constructor to initialize the serializer with a specific filename
    public Serializer(String filename) {
        this.filename = filename; // Set the filename
    }

    // Method to save an object to a file
    public void save(T object) {
        // Try-with-resources to automatically close the output stream
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(filename))) {
            oos.writeObject(object); // Write the object to the file
            System.out.println("Data successfully saved to " + filename); // Confirm successful save
        } catch (IOException e) {
            // Handle any IOException that occurs during saving
            System.err.println("Error saving data: " + e.getMessage()); // Print error message
        }
    }

    // Method to load an object from a file
    public T load() {
        T object = null; // Initialize the object to null
        // Try-with-resources to automatically close the input stream
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(filename))) {
            object = (T) ois.readObject(); // Read the object from the file
            System.out.println("Data successfully loaded from " + filename); // Confirm successful load
        } catch (FileNotFoundException e) {
            // Handle case where the file does not exist
            System.out.println("No data file found. A new file will be created upon saving."); // Inform the user
        } catch (IOException | ClassNotFoundException e) {
            // Handle any IOException or ClassNotFoundException that occurs during loading
            System.err.println("Error loading data: " + e.getMessage()); // Print error message
        }
        return object; // Return the loaded object (or null if there was an error)
    }
}
