package com.example.theatrebookingsystema1;

import javafx.application.Application;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalTime;

public class MainApplication extends Application implements Serializable {

    // Custom linked lists for managing data
    private CustomLinkedList<Show> shows = new CustomLinkedList<>();
    private CustomLinkedList<Performance> performances = new CustomLinkedList<>();
    private CustomLinkedList<Customer> customers = new CustomLinkedList<>();
    private CustomLinkedList<Booking> bookings = new CustomLinkedList<>();
    private SeatingArrangement seatingArrangement; // seating arrangement instance

    public static void main(String[] args) {
        launch(args); // launches the JavaFX application
    }

    public void start(Stage primaryStage) {
        primaryStage.setTitle("Theatre Booking System");

        // Initialize seating arrangement (10x10 layout)
        seatingArrangement = new SeatingArrangement(10, 10);

        // Set up main layout
        BorderPane root = new BorderPane();
        Scene scene = new Scene(root, 800, 600);

        // Create Menu Bar
        MenuBar menuBar = new MenuBar();

        // Shows menu with add/remove options
        Menu showMenu = new Menu("Shows");
        MenuItem addShowItem = new MenuItem("Add Show");
        addShowItem.setOnAction(event -> showAddShowDialog());
        MenuItem removeShowItem = new MenuItem("Remove Show");
        removeShowItem.setOnAction(event -> showRemoveShowDialog());
        showMenu.getItems().addAll(addShowItem, removeShowItem);

        // Performances menu with add/remove options
        Menu performanceMenu = new Menu("Performances");
        MenuItem addPerformanceItem = new MenuItem("Add Performance");
        addPerformanceItem.setOnAction(event -> showAddPerformanceDialog());
        MenuItem removePerformanceItem = new MenuItem("Remove Performance");
        removePerformanceItem.setOnAction(event -> showRemovePerformanceDialog());
        performanceMenu.getItems().addAll(addPerformanceItem, removePerformanceItem);

        // Customers menu with add/remove options
        Menu customerMenu = new Menu("Customers");
        MenuItem addCustomerItem = new MenuItem("Add Customer");
        addCustomerItem.setOnAction(event -> showAddCustomerDialog());
        MenuItem removeCustomerItem = new MenuItem("Remove Customer");
        removeCustomerItem.setOnAction(event -> showRemoveCustomerDialog());
        customerMenu.getItems().addAll(addCustomerItem, removeCustomerItem);

        // Bookings menu with add/remove options
        Menu bookingMenu = new Menu("Bookings");
        MenuItem addBookingItem = new MenuItem("Add Booking");
        addBookingItem.setOnAction(event -> showAddBookingDialog());
        MenuItem removeBookingItem = new MenuItem("Remove Booking");
        removeBookingItem.setOnAction(event -> showRemoveBookingDialog());
        bookingMenu.getItems().addAll(addBookingItem, removeBookingItem);

        // View menu with options to view data and occupancy
        Menu viewMenu = new Menu("View");
        MenuItem viewShowsItem = new MenuItem("View Shows");
        viewShowsItem.setOnAction(event -> showViewShowsDialog());
        MenuItem viewPerformancesItem = new MenuItem("View Performances");
        viewPerformancesItem.setOnAction(event -> showViewPerformancesDialog());
        MenuItem viewBookingsItem = new MenuItem("View Bookings");
        viewBookingsItem.setOnAction(event -> showViewBookingsDialog());
        MenuItem viewReceiptsItem = new MenuItem("View Total Receipts");
        viewReceiptsItem.setOnAction(event -> showTotalReceiptsDialog());
        MenuItem viewOccupancyItem = new MenuItem("View Theater Map");
        viewOccupancyItem.setOnAction(event -> showTheaterOccupancyMap());
        viewMenu.getItems().addAll(viewShowsItem, viewPerformancesItem, viewBookingsItem, viewReceiptsItem, viewOccupancyItem);

        // Data menu with options for saving, loading, and resetting data
        Menu dataMenu = new Menu("Data");
        MenuItem saveDataItem = new MenuItem("Save Data");
        saveDataItem.setOnAction(event -> {
            try {
                saveData();
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        });
        MenuItem loadDataItem = new MenuItem("Load Data");
        loadDataItem.setOnAction(event -> loadData());
        dataMenu.getItems().addAll(saveDataItem, loadDataItem);

        MenuItem resetDataItem = new MenuItem("Reset Data");
        resetDataItem.setOnAction(event -> resetAllData());
        dataMenu.getItems().add(resetDataItem);

        // Add menus to the menu bar
        menuBar.getMenus().addAll(showMenu, performanceMenu, customerMenu, bookingMenu, viewMenu, dataMenu);

        // Set the menu bar at the top of the layout
        root.setTop(menuBar);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    // Remove a show and cascade delete related performances and bookings
    private void removeShow(Show showToRemove) {
        if (showToRemove != null) {
            // Remove performances related to the show
            CustomLinkedList.Node<Performance> performanceNode = performances.getHead();
            while (performanceNode != null) {
                Performance performance = performanceNode.data;
                if (performance.getShow().equals(showToRemove)) {
                    removePerformance(performance); // Use existing method to remove performance and related bookings
                }
                performanceNode = performanceNode.next;
            }

            // Remove the show itself
            shows.remove(showToRemove);
            System.out.println("Show and all associated data removed: " + showToRemove);
        }
    }


    // Remove a performance and cascade delete related bookings
    private void removePerformance(Performance performanceToRemove) {
        if (performanceToRemove != null) {
            performances.remove(performanceToRemove); // remove the performance
            CustomLinkedList.Node<Booking> bookingNode = bookings.getHead();
            while (bookingNode != null) {
                Booking booking = bookingNode.data;
                if (booking.getPerformance().equals(performanceToRemove)) {
                    bookings.remove(booking); // remove related bookings
                    System.out.println("Booking removed due to performance cancellation: " + booking);
                }
                bookingNode = bookingNode.next;
            }
            System.out.println("Performance and all associated bookings removed: " + performanceToRemove);
        }
    }

    // Remove a customer and cascade delete related bookings
    private void removeCustomer(Customer customerToRemove) {
        if (customerToRemove != null) {
            // Remove all bookings associated with this customer
            CustomLinkedList.Node<Booking> bookingNode = bookings.getHead();
            while (bookingNode != null) {
                Booking booking = bookingNode.data;
                if (booking.getCustomer().equals(customerToRemove)) {
                    bookings.remove(booking);
                    System.out.println("Booking removed due to customer deletion: " + booking);
                }
                bookingNode = bookingNode.next;
            }

            // Finally, remove the customer
            customers.remove(customerToRemove);
            System.out.println("Customer and all associated bookings removed: " + customerToRemove);
        }
    }

    // Remove a single booking
    private void removeBooking(Booking bookingToRemove) {
        if (bookingToRemove != null) {
            bookings.remove(bookingToRemove);
            System.out.println("Booking removed: " + bookingToRemove);
        }
    }

    // Dialog for adding a show
    private void showAddShowDialog() {
        Dialog<Show> dialog = new Dialog<>();
        dialog.setTitle("Add Show");

        ButtonType addButtonType = new ButtonType("Add", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(addButtonType, ButtonType.CANCEL);

        VBox vbox = new VBox(10);

        // Input fields for show details
        TextField titleField = new TextField();
        titleField.setPromptText("Show Title");

        TextField runningTimeField = new TextField();
        runningTimeField.setPromptText("Running Time (minutes)");

        DatePicker startDatePicker = new DatePicker();
        DatePicker endDatePicker = new DatePicker();

        TextField stallPriceField = new TextField();
        stallPriceField.setPromptText("Stall Price");

        TextField circlePriceField = new TextField();
        circlePriceField.setPromptText("Circle Price");

        TextField balconyPriceField = new TextField();
        balconyPriceField.setPromptText("Balcony Price");

        vbox.getChildren().addAll(titleField, runningTimeField, startDatePicker, endDatePicker, stallPriceField, circlePriceField, balconyPriceField);
        dialog.getDialogPane().setContent(vbox);

        // Handle adding the new show
        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == addButtonType) {
                try {
                    String title = titleField.getText();
                    int runningTime = Integer.parseInt(runningTimeField.getText());
                    LocalDate startDate = startDatePicker.getValue();
                    LocalDate endDate = endDatePicker.getValue();
                    double stallPrice = Double.parseDouble(stallPriceField.getText());
                    double circlePrice = Double.parseDouble(circlePriceField.getText());
                    double balconyPrice = Double.parseDouble(balconyPriceField.getText());

                    Show newShow = new Show(title, runningTime, startDate, endDate, stallPrice, circlePrice, balconyPrice);
                    shows.add(newShow);
                    return newShow;

                } catch (Exception e) {
                    showAlert("Input Error", "Please ensure all fields are filled correctly.");
                }
            }
            return null;
        });

        dialog.showAndWait();
    }

    // Dialog for adding a performance
    private void showAddPerformanceDialog() {
        Dialog<Performance> dialog = new Dialog<>();
        dialog.setTitle("Add Performance");

        ButtonType addButtonType = new ButtonType("Add", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(addButtonType, ButtonType.CANCEL);

        VBox vbox = new VBox(10);

        // Input fields for performance details
        DatePicker datePicker = new DatePicker();
        ComboBox<Show> showComboBox = new ComboBox<>();
        CustomLinkedList.Node<Show> currentShowNode = shows.getHead();
        while (currentShowNode != null) {
            showComboBox.getItems().add(currentShowNode.data);
            currentShowNode = currentShowNode.next;
        }

        TextField timeField = new TextField();
        timeField.setPromptText("Time (HH:MM)");

        vbox.getChildren().addAll(datePicker, showComboBox, timeField);
        dialog.getDialogPane().setContent(vbox);

        // Handle adding the performance
        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == addButtonType) {
                try {
                    LocalDate date = datePicker.getValue();
                    Show show = showComboBox.getValue();
                    LocalTime time = LocalTime.parse(timeField.getText());

                    Performance newPerformance = new Performance(date, show, time);
                    performances.add(newPerformance);
                    return newPerformance;

                } catch (Exception e) {
                    showAlert("Input Error", "Please ensure all fields are filled correctly.");
                }
            }
            return null;
        });

        dialog.showAndWait();
    }

    // Method to show dialog for adding a customer
    private void showAddCustomerDialog() {
        Dialog<Customer> dialog = new Dialog<>();
        dialog.setTitle("Add Customer");

        ButtonType addButtonType = new ButtonType("Add", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(addButtonType, ButtonType.CANCEL);

        VBox vbox = new VBox(10);

        // Input fields for customer details
        TextField nameField = new TextField();
        nameField.setPromptText("Customer Name");

        TextField emailField = new TextField();
        emailField.setPromptText("Email Address");

        TextField phoneNumberField = new TextField();
        phoneNumberField.setPromptText("Phone Number");

        vbox.getChildren().addAll(nameField, emailField, phoneNumberField);
        dialog.getDialogPane().setContent(vbox);

        // Handle adding the customer
        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == addButtonType) {
                String name = nameField.getText();
                String email = emailField.getText();
                String phoneNumber = phoneNumberField.getText();

                Customer newCustomer = new Customer(name, email, phoneNumber);
                customers.add(newCustomer);
                return newCustomer;
            }
            return null;
        });

        dialog.showAndWait();
    }

    // Dialog for adding a booking
    private void showAddBookingDialog() {
        Dialog<Booking> dialog = new Dialog<>();
        dialog.setTitle("Add Booking");

        ButtonType addButtonType = new ButtonType("Add", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(addButtonType, ButtonType.CANCEL);

        VBox vbox = new VBox(10);

        // ComboBoxes for selecting show, performance, and customer
        ComboBox<Show> showComboBox = new ComboBox<>();
        ComboBox<Performance> performanceComboBox = new ComboBox<>();
        ComboBox<Customer> customerComboBox = new ComboBox<>();

        // Populate Show ComboBox
        CustomLinkedList.Node<Show> currentShowNode = shows.getHead();
        while (currentShowNode != null) {
            showComboBox.getItems().add(currentShowNode.data);
            currentShowNode = currentShowNode.next;
        }

        // Add listener to Show ComboBox to filter performances
        showComboBox.setOnAction(event -> {
            Show selectedShow = showComboBox.getValue();
            performanceComboBox.getItems().clear(); // Clear previous performances
            if (selectedShow != null) {
                CustomLinkedList.Node<Performance> currentPerformanceNode = performances.getHead();
                while (currentPerformanceNode != null) {
                    Performance performance = currentPerformanceNode.data;
                    if (performance.getShow().equals(selectedShow)) {
                        performanceComboBox.getItems().add(performance); // Add matching performances
                    }
                    currentPerformanceNode = currentPerformanceNode.next;
                }
            }
        });

        // Populate Customer ComboBox
        CustomLinkedList.Node<Customer> currentCustomerNode = customers.getHead();
        while (currentCustomerNode != null) {
            customerComboBox.getItems().add(currentCustomerNode.data);
            currentCustomerNode = currentCustomerNode.next;
        }

        // Seating sections layout
        VBox seatingVBox = new VBox(10);
        Label balconyLabel = new Label("Balcony Section");
        GridPane balconyGridPane = createToggleGridPane(0, 3, 0, 8);
        seatingVBox.getChildren().addAll(balconyLabel, balconyGridPane);

        Label circleLabel = new Label("Circle Section");
        GridPane circleGridPane = createToggleGridPane(3, 6, 0, 10);
        seatingVBox.getChildren().addAll(circleLabel, circleGridPane);

        Label stallLabel = new Label("Stall Section");
        GridPane stallGridPane = createToggleGridPane(6, 10, 0, 10);
        seatingVBox.getChildren().addAll(stallLabel, stallGridPane);

        // Add ComboBoxes and seating sections to the layout
        vbox.getChildren().addAll(showComboBox, performanceComboBox, customerComboBox, seatingVBox);
        dialog.getDialogPane().setContent(vbox);

        // Handle adding the booking
        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == addButtonType) {
                Show selectedShow = showComboBox.getValue();
                Performance selectedPerformance = performanceComboBox.getValue();
                Customer selectedCustomer = customerComboBox.getValue();

                // Collect booked seats
                CustomLinkedList<Seat> bookedSeats = new CustomLinkedList<>();
                bookedSeats.addAll(getSelectedSeatsFromGrid(balconyGridPane, 0, 3, 0, 8));
                bookedSeats.addAll(getSelectedSeatsFromGrid(circleGridPane, 3, 6, 0, 10));
                bookedSeats.addAll(getSelectedSeatsFromGrid(stallGridPane, 6, 10, 0, 10));

                if (selectedShow != null && selectedPerformance != null && selectedCustomer != null && bookedSeats.size() > 0) {
                    return new Booking(selectedShow, selectedCustomer, selectedPerformance, bookedSeats);
                } else {
                    showAlert("Input Error", "Please select all fields and book at least one seat");
                }
            }
            return null;
        });

        dialog.showAndWait().ifPresent(booking -> {
            bookings.add(booking); // Add booking to the list
            System.out.println("Booking added: " + booking);
        });
    }


    // Helper method to get selected seats from a seating grid
    private CustomLinkedList<Seat> getSelectedSeatsFromGrid(GridPane gridPane, int rowStart, int rowEnd, int colStart, int colEnd) {
        CustomLinkedList<Seat> selectedSeats = new CustomLinkedList<>();

        for (Node node : gridPane.getChildren()) {
            if (node instanceof Button) {
                Button seatButton = (Button) node;
                if (seatButton.getText().equals("Selected")) {
                    int rowIndex = GridPane.getRowIndex(seatButton) + rowStart;
                    int colIndex = GridPane.getColumnIndex(seatButton) + colStart;

                    Seat seat = seatingArrangement.getSeat(rowIndex, colIndex);
                    if (!containsSeat(selectedSeats, seat)) {
                        selectedSeats.add(seat);
                    }
                }
            }
        }
        return selectedSeats;
    }

    // Helper to check for duplicate seats in the list
    private boolean containsSeat(CustomLinkedList<Seat> seats, Seat seatToCheck) {
        CustomLinkedList.Node<Seat> currentNode = seats.getHead();
        while (currentNode != null) {
            if (currentNode.data.equals(seatToCheck)) {
                return true;
            }
            currentNode = currentNode.next;
        }
        return false;
    }

    // Creates a toggleable seating grid for selection
    private GridPane createToggleGridPane(int rowStart, int rowEnd, int colStart, int colEnd) {
        GridPane gridPane = new GridPane();

        for (int i = rowStart; i < rowEnd; i++) {
            for (int j = colStart; j < colEnd; j++) {
                Seat seat = seatingArrangement.getSeat(i, j);
                Button seatButton = new Button("Available");

                seatButton.setOnAction(event -> {
                    if (seatButton.getText().equals("Available")) {
                        seatButton.setText("Selected");
                    } else {
                        seatButton.setText("Available");
                    }
                });

                gridPane.add(seatButton, j, i - rowStart);
            }
        }
        return gridPane;
    }

    // Helper method to show an error alert
    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }

    // Dialog for removing a show
    private void showRemoveShowDialog() {
        Dialog<Show> dialog = new Dialog<>();
        dialog.setTitle("Remove Show");

        // Add Remove and Cancel buttons
        ButtonType removeButtonType = new ButtonType("Remove", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(removeButtonType, ButtonType.CANCEL);

        // ComboBox to select the show to remove
        ComboBox<Show> showComboBox = new ComboBox<>();
        CustomLinkedList.Node<Show> currentShowNode = shows.getHead();
        while (currentShowNode != null) {
            showComboBox.getItems().add(currentShowNode.data);
            currentShowNode = currentShowNode.next;
        }

        VBox vbox = new VBox(10, showComboBox);
        dialog.getDialogPane().setContent(vbox);

        // Define result converter
        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == removeButtonType) {
                Show selectedShow = showComboBox.getValue();
                if (selectedShow != null) {
                    removeShow(selectedShow); // Use the updated method to handle removal
                    Alert alert = new Alert(Alert.AlertType.INFORMATION, "Show removed successfully: " + selectedShow.getTitle());
                    alert.showAndWait();
                } else {
                    Alert alert = new Alert(Alert.AlertType.WARNING, "No show selected.");
                    alert.showAndWait();
                }
            }
            return null;
        });

        // Show the dialog
        dialog.showAndWait();
    }


    // Dialog for removing a performance
    private void showRemovePerformanceDialog() {
        Dialog<Performance> dialog = new Dialog<>();
        dialog.setTitle("Remove Performance");

        ButtonType removeButtonType = new ButtonType("Remove", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(removeButtonType, ButtonType.CANCEL);

        ComboBox<Performance> performanceComboBox = new ComboBox<>();
        CustomLinkedList.Node<Performance> currentNode = performances.getHead();
        while (currentNode != null) {
            performanceComboBox.getItems().add(currentNode.data);
            currentNode = currentNode.next;
        }

        VBox vbox = new VBox(10, performanceComboBox);
        dialog.getDialogPane().setContent(vbox);

        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == removeButtonType) {
                Performance selectedPerformance = performanceComboBox.getValue();
                if (selectedPerformance != null) {
                    // Remove all bookings associated with this performance
                    CustomLinkedList.Node<Booking> bookingNode = bookings.getHead();
                    while (bookingNode != null) {
                        Booking booking = bookingNode.data;
                        if (booking.getPerformance().equals(selectedPerformance)) {
                            bookings.remove(booking);
                            System.out.println("Booking removed due to performance cancellation: " + booking);
                        }
                        bookingNode = bookingNode.next;
                    }
                    performances.remove(selectedPerformance);
                    System.out.println("Performance and all associated bookings removed: " + selectedPerformance);
                }
            }
            return null;
        });

        dialog.showAndWait();
    }

    // Dialog for removing a customer
    private void showRemoveCustomerDialog() {
        // Check if there are any customers to remove
        if (customers.getHead() == null) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION, "No customers available to remove.");
            alert.showAndWait();
            return; // Exit the method
        }

        // Create the dialog
        Dialog<Customer> dialog = new Dialog<>();
        dialog.setTitle("Remove Customer");

        // Add Remove and Cancel buttons
        ButtonType removeButtonType = new ButtonType("Remove", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(removeButtonType, ButtonType.CANCEL);

        // Populate ComboBox with Customer objects
        ComboBox<Customer> customerComboBox = new ComboBox<>();
        CustomLinkedList.Node<Customer> currentNode = customers.getHead();
        while (currentNode != null) {
            customerComboBox.getItems().add(currentNode.data);
            currentNode = currentNode.next;
        }

        VBox vbox = new VBox(10, customerComboBox);
        dialog.getDialogPane().setContent(vbox);

        // Define result converter
        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == removeButtonType) {
                Customer selectedCustomer = customerComboBox.getValue();
                if (selectedCustomer != null) {
                    removeCustomer(selectedCustomer); // Use the centralized method
                    Alert alert = new Alert(Alert.AlertType.INFORMATION,
                            "Customer removed successfully.\nCustomer: " + selectedCustomer.getName());
                    alert.showAndWait();
                } else {
                    Alert alert = new Alert(Alert.AlertType.WARNING, "No customer selected.");
                    alert.showAndWait();
                }
            }
            return null;
        });

        // Show the dialog
        dialog.showAndWait();
    }


    // Dialog for removing a booking
    private void showRemoveBookingDialog() {
        // Check if there are any bookings to remove
        if (bookings.getHead() == null) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION, "No bookings available to remove.");
            alert.showAndWait();
            return; // Exit the method
        }

        // Create the dialog
        Dialog<Booking> dialog = new Dialog<>();
        dialog.setTitle("Remove Booking");

        // Add Remove and Cancel buttons
        ButtonType removeButtonType = new ButtonType("Remove", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(removeButtonType, ButtonType.CANCEL);

        // Populate ComboBox with Booking objects
        ComboBox<Booking> bookingComboBox = new ComboBox<>();
        CustomLinkedList.Node<Booking> currentNode = bookings.getHead();
        while (currentNode != null) {
            bookingComboBox.getItems().add(currentNode.data);
            currentNode = currentNode.next;
        }

        VBox vbox = new VBox(10, bookingComboBox);
        dialog.getDialogPane().setContent(vbox);

        // Define result converter
        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == removeButtonType) {
                Booking selectedBooking = bookingComboBox.getValue();
                if (selectedBooking != null) {
                    removeBooking(selectedBooking); // Use the centralized method
                    Alert alert = new Alert(Alert.AlertType.INFORMATION,
                            "Booking removed successfully.\nBooking ID: " + selectedBooking.getBookingId());
                    alert.showAndWait();
                } else {
                    Alert alert = new Alert(Alert.AlertType.WARNING, "No booking selected.");
                    alert.showAndWait();
                }
            }
            return null;
        });

        // Show the dialog
        dialog.showAndWait();
    }




    // Display a dialog with a table view of shows
    private void showViewShowsDialog() {
        Dialog<Void> dialog = new Dialog<>();
        dialog.setTitle("View Shows");

        TableView<Show> table = new TableView<>();
        TableColumn<Show, String> titleColumn = new TableColumn<>("Title");
        titleColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getTitle()));

        TableColumn<Show, Integer> runtimeColumn = new TableColumn<>("Running Time");
        runtimeColumn.setCellValueFactory(data -> new SimpleIntegerProperty(data.getValue().getRunningTime()).asObject());

        TableColumn<Show, String> dateColumn = new TableColumn<>("Date Range");
        dateColumn.setCellValueFactory(data -> new SimpleStringProperty(
                data.getValue().getStartDate() + " - " + data.getValue().getEndDate()));

        table.getColumns().addAll(titleColumn, runtimeColumn, dateColumn);

        // Populate table from CustomLinkedList
        CustomLinkedList.Node<Show> currentNode = shows.getHead();
        while (currentNode != null) {
            table.getItems().add(currentNode.data);
            currentNode = currentNode.next;
        }

        VBox vbox = new VBox(table);
        dialog.getDialogPane().setContent(vbox);
        dialog.getDialogPane().getButtonTypes().add(ButtonType.CLOSE);
        dialog.showAndWait();
    }

    // Display a dialog with a table view of performances
    private void showViewPerformancesDialog() {
        Dialog<Void> dialog = new Dialog<>();
        dialog.setTitle("View Performances");

        TableView<Performance> table = new TableView<>();
        TableColumn<Performance, String> showColumn = new TableColumn<>("Show Title");
        showColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getShow().getTitle()));

        TableColumn<Performance, String> dateColumn = new TableColumn<>("Date");
        dateColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getDate().toString()));

        TableColumn<Performance, String> timeColumn = new TableColumn<>("Time");
        timeColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getTime().toString()));

        table.getColumns().addAll(showColumn, dateColumn, timeColumn);

        // Populate table from CustomLinkedList
        CustomLinkedList.Node<Performance> currentNode = performances.getHead();
        while (currentNode != null) {
            table.getItems().add(currentNode.data);
            currentNode = currentNode.next;
        }

        VBox vbox = new VBox(table);
        dialog.getDialogPane().setContent(vbox);
        dialog.getDialogPane().getButtonTypes().add(ButtonType.CLOSE);
        dialog.showAndWait();
    }

    // Display a dialog with a table view of bookings
    private void showViewBookingsDialog() {
        // Check if there are any bookings to display
        if (bookings.getHead() == null) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION, "No bookings available to view.");
            alert.showAndWait();
            return; // Exit the method
        }

        // Create the dialog
        Dialog<Void> dialog = new Dialog<>();
        dialog.setTitle("View Bookings");

        // Create the table
        TableView<Booking> table = new TableView<>();

        // Define columns
        TableColumn<Booking, String> bookingIdColumn = new TableColumn<>("Booking ID");
        bookingIdColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getBookingId())); // Booking ID column

        TableColumn<Booking, String> showColumn = new TableColumn<>("Show Title");
        showColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getShow().getTitle()));

        TableColumn<Booking, String> customerColumn = new TableColumn<>("Customer Name");
        customerColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getCustomer().getName()));

        TableColumn<Booking, String> performanceColumn = new TableColumn<>("Performance Date/Time");
        performanceColumn.setCellValueFactory(data -> new SimpleStringProperty(
                data.getValue().getPerformance().getDate() + " at " + data.getValue().getPerformance().getTime()));

        TableColumn<Booking, Integer> seatsColumn = new TableColumn<>("Seats Booked");
        seatsColumn.setCellValueFactory(data -> new SimpleIntegerProperty(data.getValue().getBookedSeats().size()).asObject());

        // Add columns to the table
        table.getColumns().addAll(bookingIdColumn, showColumn, customerColumn, performanceColumn, seatsColumn);

        // Populate table from CustomLinkedList bookings
        CustomLinkedList.Node<Booking> currentNode = bookings.getHead();
        while (currentNode != null) {
            table.getItems().add(currentNode.data); // Add booking to the table
            currentNode = currentNode.next;
        }

        // Add the table to the dialog
        VBox vbox = new VBox(table);
        dialog.getDialogPane().setContent(vbox);
        // Add a close button
        dialog.getDialogPane().getButtonTypes().add(ButtonType.CLOSE);

        // Show the dialog
        dialog.showAndWait();
    }


    // Show total receipts from all bookings
    private void showTotalReceiptsDialog() {
        double totalReceipts = 0.0;

        CustomLinkedList.Node<Booking> currentNode = bookings.getHead();
        while (currentNode != null) {
            totalReceipts += currentNode.data.getTotalPrice();  // Calculate total price
            currentNode = currentNode.next;
        }

        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Total Receipts");
        alert.setHeaderText("Total Receipts from All Bookings");
        alert.setContentText("Total Receipts: $" + String.format("%.2f", totalReceipts));
        alert.showAndWait();
    }

    // Show theater seating occupancy map
    private void showTheaterOccupancyMap() {
        Dialog<Void> dialog = new Dialog<>();
        dialog.setTitle("Theater Occupancy");

        VBox occupancyView = new VBox();
        occupancyView.setSpacing(10);
        occupancyView.setPrefSize(700, 600);

        occupancyView.getChildren().add(new Label("Select Performance:"));

        ComboBox<Performance> performanceComboBox = new ComboBox<>();
        CustomLinkedList.Node<Performance> currentPerformanceNode = performances.getHead();
        while (currentPerformanceNode != null) {
            performanceComboBox.getItems().add(currentPerformanceNode.data);
            currentPerformanceNode = currentPerformanceNode.next;
        }

        // Update seating view when performance selected
        performanceComboBox.setOnAction(event -> {
            occupancyView.getChildren().clear();
            Performance selectedPerformance = performanceComboBox.getValue();

            if (selectedPerformance != null) {
                Label balconyLabel = new Label("Balcony Section");
                GridPane balconyGrid = seatingArrangement.createGridPaneForSection(0, 3, 0, 8);

                Label circleLabel = new Label("Circle Section");
                GridPane circleGrid = seatingArrangement.createGridPaneForSection(3, 6, 0, 10);

                Label stallLabel = new Label("Stall Section");
                GridPane stallGrid = seatingArrangement.createGridPaneForSection(6, 10, 0, 10);

                occupancyView.getChildren().addAll(
                        new Label("Occupancy Map:"),
                        balconyLabel, balconyGrid,
                        circleLabel, circleGrid,
                        stallLabel, stallGrid
                );
            }
        });

        VBox vbox = new VBox(10, performanceComboBox, occupancyView);
        dialog.getDialogPane().setContent(vbox);
        dialog.getDialogPane().getButtonTypes().add(ButtonType.CLOSE);
        dialog.showAndWait();
    }

    // Save all data to files
    public void saveData() {
        Serializer<CustomLinkedList<Show>> showSerializer = new Serializer<>("shows.dat");
        showSerializer.save(shows);

        Serializer<CustomLinkedList<Performance>> performanceSerializer = new Serializer<>("performances.dat");
        performanceSerializer.save(performances);

        Serializer<CustomLinkedList<Customer>> customerSerializer = new Serializer<>("customers.dat");
        customerSerializer.save(customers);

        Serializer<CustomLinkedList<Booking>> bookingSerializer = new Serializer<>("bookings.dat");
        bookingSerializer.save(bookings);
    }

    // Load data from files
    public void loadData() {
        Serializer<CustomLinkedList<Show>> showSerializer = new Serializer<>("shows.dat");
        shows = showSerializer.load();
        if (shows == null) {
            shows = new CustomLinkedList<>();
        }

        Serializer<CustomLinkedList<Performance>> performanceSerializer = new Serializer<>("performances.dat");
        performances = performanceSerializer.load();
        if (performances == null) {
            performances = new CustomLinkedList<>();
        }

        Serializer<CustomLinkedList<Customer>> customerSerializer = new Serializer<>("customers.dat");
        customers = customerSerializer.load();
        if (customers == null) {
            customers = new CustomLinkedList<>();
        }

        Serializer<CustomLinkedList<Booking>> bookingSerializer = new Serializer<>("bookings.dat");
        bookings = bookingSerializer.load();
        if (bookings == null) {
            bookings = new CustomLinkedList<>();
        }
    }

    // Reset all data
    public void resetAllData() {
        shows.clear();
        performances.clear();
        customers.clear();
        bookings.clear();

        System.out.println("All data has been reset.");

        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Data Reset");
        alert.setHeaderText(null);
        alert.setContentText("All shows, performances, customers, and bookings have been cleared.");
        alert.showAndWait();
    }
}


