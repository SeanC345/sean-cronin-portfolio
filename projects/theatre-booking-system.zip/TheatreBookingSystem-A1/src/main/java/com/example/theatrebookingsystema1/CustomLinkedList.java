package com.example.theatrebookingsystema1;

import java.io.Serializable;

public class CustomLinkedList<T extends Serializable> implements Serializable {
    private Node<T> head; // The first node in the linked list
    private int size; // The number of elements in the linked list
    private static final long serialVersionUID = 1L; // Version control for serialization

    // Inner class to represent each node in the linked list
    static class Node<T> implements Serializable {
        T data; // The data stored in this node
        Node<T> next; // A reference to the next node in the list

        // Constructor to create a new node with the given data
        public Node(T data) {
            this.data = data; // Set the data of the node
            this.next = null; // Initialize next as null (no next node yet)
        }
    }

    // Constructor to initialize the custom linked list
    public CustomLinkedList() {
        this.head = null; // Start with an empty list (no head node)
        this.size = 0; // Start with size 0
    }

    // Return the current size of the linked list (how many elements it contains)
    public int size() {
        return size; // Return the size of the list
    }

    // Return the head of the linked list (the first node)
    public Node<T> getHead() {
        return head; // Return the head node
    }

    // Add a new element to the end of the linked list
    public void add(T data) {
        Node<T> newNode = new Node<>(data); // Create a new node with the provided data
        if (head == null) {
            head = newNode; // If the list is empty, the new node becomes the head
        } else {
            Node<T> current = head; // Start from the head
            // Traverse to the last node
            while (current.next != null) {
                current = current.next; // Move to the next node
            }
            // Append the new node at the end of the list
            current.next = newNode; // Link the last node to the new node
        }
        size++; // Increase the size of the list
    }

    // Add all elements from another CustomLinkedList to this list
    public void addAll(CustomLinkedList<T> otherList) {
        Node<T> currentNode = otherList.getHead(); // Start at the head of the other list
        while (currentNode != null) {
            this.add(currentNode.data); // Add each element to this list
            currentNode = currentNode.next; // Move to the next node in the other list
        }
    }

    // Remove the first occurrence of the element that matches the provided data
    public void remove(T data) {
        if (head == null) return; // If the list is empty, there's nothing to remove

        // Special case: the head node contains the data we want to remove
        if (head.data.equals(data)) {
            head = head.next; // Update the head to the next node
            size--; // Decrease the size of the list
            return; // Exit the method
        }

        // General case: find the node to remove
        Node<T> current = head; // Start from the head
        while (current.next != null) {
            if (current.next.data.equals(data)) { // Check if the next node contains the data
                current.next = current.next.next; // Skip the node with the matching data
                size--; // Decrease the size of the list
                return; // Exit the method
            }
            current = current.next; // Move to the next node
        }
    }

    // Clear the entire linked list (remove all elements)
    public void clear() {
        head = null; // Set the head to null (no nodes)
        size = 0; // Reset size to 0
    }

}

