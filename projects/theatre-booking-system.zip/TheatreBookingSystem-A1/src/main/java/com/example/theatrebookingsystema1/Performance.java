package com.example.theatrebookingsystema1;

import java.io.Serializable;
import java.time.LocalDate; // Importing LocalDate class for handling dates
import java.time.LocalTime; // Importing LocalTime class for handling times

public class Performance implements Serializable {
    private LocalDate date; // The date of the performance
    private LocalTime time; // The time of the performance
    private Show show; // The show being performed
    private static final long serialVersionUID = 1L; // Version control for serialization

    // Constructor to create a performance with a specific date, time, and show
    public Performance(LocalDate date, Show show, LocalTime time) {
        this.date = date;
        this.show = show;
        this.time = time;
    }

    // Method to get the show associated with this performance
    public Show getShow() {
        return show; // Return the show
    }

    // Method to get the date of the performance
    public LocalDate getDate() {
        return date; // Return the date
    }

    // Method to get the time of the performance
    public LocalTime getTime() {
        return time; // Return the time
    }

    // Method to return a string representation of the performance details
    @Override
    public String toString() {
        return String.format(
                "Performance Details:\n" +
                        "Show: %s\n" +
                        "Date: %s\n" +
                        "Time: %s",
                show.getTitle(),
                date,
                time
        );
    }
}


