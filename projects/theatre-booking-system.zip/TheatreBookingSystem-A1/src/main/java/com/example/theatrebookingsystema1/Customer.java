package com.example.theatrebookingsystema1;
import java.io.Serializable; // Importing Serializable interface for object serialization

public class Customer implements Serializable {
    private String name; // Customer's name
    private String email; // Customer's email address
    private String phoneNumber; // Customer's phone number
    private static final long serialVersionUID = 1L; // Version control for serialization

    // Constructor to initialize a new customer with name, email, and phone number
    public Customer(String name, String email, String phoneNumber) {
        this.name = name; // Set the customer's name
        this.email = email; // Set the customer's email
        setPhoneNumber(phoneNumber); // Call to setPhoneNumber for validation
    }

    // Get the customer's email address
    public String getEmail() {
        return email; // Return the email
    }

    // Set a new email address for the customer
    public void setEmail(String email) {
        this.email = email; // Update the email
    }

    // Get the customer's name
    public String getName() {
        return name; // Return the name
    }

    // Set a new name for the customer
    public void setName(String name) {
        this.name = name; // Update the name
    }

    // Get the customer's phone number
    public String getPhoneNumber() {
        return phoneNumber; // Return the phone number
    }

    // Set a new phone number for the customer
    public void setPhoneNumber(String phoneNumber) {
        // Check if the phone number is valid (exactly 10 digits)
        if (phoneNumber != null && phoneNumber.matches("\\d{10}")) {
            this.phoneNumber = phoneNumber; // Update the phone number
        } else {
            // If the phone number is not valid, throw an exception
            throw new IllegalArgumentException("Phone number must be exactly 10 digits.");
        }
    }

    // Return a string representation of the customer
    @Override
    public String toString() {
        return String.format(
                "Customer Details:\n" +
                        "Name: %s\n" +
                        "Email: %s\n" +
                        "Phone Number: %s",
                name,
                email,
                phoneNumber
        );
    }

}

