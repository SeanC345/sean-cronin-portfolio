package com.example.theatrebookingsystema1;

import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.layout.GridPane;

import java.io.Serializable;

public class SeatingArrangement implements Serializable {
    private Seat[][] seats; // 2D array representing the seating arrangement
    private static final long serialVersionUID = 1L; // Version control for serialization

    // Constructor to create a seating arrangement with specified rows and columns
    public SeatingArrangement(int rows, int cols) {
        seats = new Seat[rows][cols]; // Initialize the 2D array for seats
        initializeSeats(); // Fill the seats with numbers
    }

    public Seat getSeat(int row, int col) {
        if (row >= 0 && row < seats.length && col >= 0 && col < seats[row].length) {
            return seats[row][col];
        } else {
            return null; // Return null if the row/col are out of bounds
        }
    }

    // Method to get the number of columns in the seating arrangement
    public int getColumns() {
        return seats[0].length;
    }

    // Initialize seats with seat numbers
    private void initializeSeats() {
        int seatNumber = 1; // Start numbering seats from 1
        for (int i = 0; i < seats.length; i++) { // Iterate over rows
            for (int j = 0; j < seats[i].length; j++) { // Iterate over columns
                seats[i][j] = new Seat(seatNumber++); // Create a new Seat with the current number
            }
        }
    }

    // Book a seat and update its state
    public boolean bookSeat(int row, int col) {
        // Check if the provided row and column are valid
        if (row >= 0 && row < seats.length && col >= 0 && col < seats[row].length) {
            Seat seat = seats[row][col]; // Get the seat at the specified location
            // Check if the seat is not already booked
            if (!seat.isBooked()) {
                seat.bookSeat(); // Mark the seat as booked
                return true; // Return true to indicate success
            }
        }
        return false; // Return false if booking was unsuccessful
    }

    // Create a GridPane for seating sections (Balcony, Circle, Stall)
    public GridPane createGridPaneForSection(int rowStart, int rowEnd, int colStart, int colEnd) {
        GridPane gridPane = new GridPane();

        for (int i = rowStart; i < rowEnd; i++) {
            for (int j = colStart; j < colEnd; j++) {
                Seat seat = seats[i][j];  // Retrieve seat from the 2D array
                Button seatButton = new Button(seat.toString());  // Display "Booked" or "Seat [Number]"

                // Update button text based on booking status
                seatButton.setText(seat.isBooked() ? "Booked" : "Seat " + seat.getSeatNumber());

                int finalI = i;
                int finalJ = j;

                seatButton.setOnAction(event -> {
                    if (!seat.isBooked()) {
                        bookSeat(finalI, finalJ);  // Book the seat
                        seatButton.setText("Booked");  // Update button to show "Booked"
                    } else {
                        Alert alert = new Alert(Alert.AlertType.ERROR, "Seat is already booked");
                        alert.showAndWait();
                    }
                });

                gridPane.add(seatButton, j, i - rowStart);
            }
        }
        return gridPane;
    }

}

