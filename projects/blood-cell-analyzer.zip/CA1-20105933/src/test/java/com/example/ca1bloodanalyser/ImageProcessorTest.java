package com.example.ca1bloodanalyser;

import javafx.scene.image.Image;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

class ImageProcessorTest {

    ImageProcessor processor = new ImageProcessor(); // Create an instance of ImageProcessor

    /**
     * Tests hue and saturation adjustment on an image.
     */
    @Test
    void testApplyHueSaturationAdjustment() {
        Image original = new Image(getClass().getResourceAsStream("/bloodcellsample.png")); // Load test image
        Image adjusted = processor.applyHueSaturationAdjustment(original, 30, 1.2, 0.1); // Apply adjustment
        assertNotNull(adjusted, "Adjusted image should not be null"); // Ensure image is processed
        assertEquals(original.getWidth(), adjusted.getWidth(), "Width must remain the same"); // Check width unchanged
        assertEquals(original.getHeight(), adjusted.getHeight(), "Height must remain the same"); // Check height unchanged
    }

    /**
     * Tests the conversion of an image to tricolor format.
     */
    @Test
    void testConvertToTricolor() {
        Image original = new Image(getClass().getResourceAsStream("/bloodcellsample.png")); // Load test image
        Image triColor = processor.convertToTricolor(original, 260); // Convert to tricolor
        assertNotNull(triColor, "Tri-color image should not be null"); // Ensure conversion succeeded
        assertEquals(original.getWidth(), triColor.getWidth(), "Width must remain the same"); // Check width unchanged
        assertEquals(original.getHeight(), triColor.getHeight(), "Height must remain the same"); // Check height unchanged
    }

    /**
     * Tests the clamp method to ensure values are properly constrained.
     */
    @Test
    void testClampMethod() {
        assertEquals(0.5, processor.clamp(0.5, 0, 1), 0.0001); // Check within bounds
        assertEquals(1, processor.clamp(1.5, 0, 1), 0.0001); // Check upper bound
        assertEquals(0, processor.clamp(-0.5, 0, 1), 0.0001); // Check lower bound
    }
}
