package com.example.ca1bloodanalyser;

// Import required JUnit libraries for testing.
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class BloodCellAnalyserTest {
    // Create an instance of BloodCellAnalyser to be used in all the tests.
    BloodCellAnalyser analyser = new BloodCellAnalyser();

    /**
     * Test the union-find algorithm implementation to ensure it correctly connects and identifies connected elements.
     */
    @Test
    void testUnionFindAlgorithm() {
        // Initialize the parent array with all elements being their own parent (indicative of -1).
        int[] parent = {-1, -1, -1, -1};

        // Connect element 0 with 1 and 1 with 2, thereby transitively connecting 0 with 2.
        analyser.union(parent, 0, 1);
        analyser.union(parent, 1, 2);

        // Check if element 0 and 2 are correctly identified as being connected.
        assertEquals(analyser.find(parent, 0), analyser.find(parent, 2), "Elements should be connected");

        // Check if element 0 and 3 are correctly identified as not being connected.
        assertNotEquals(analyser.find(parent, 0), analyser.find(parent, 3), "Element 3 should not be connected");
    }

    /**
     * Test the boundary calculations in the Boundary inner class to verify if updates correctly adjust the boundaries.
     */
    @Test
    void testBoundaryCalculations() {
        // Create a new Boundary object starting at position (10, 15) and type 1.
        BloodCellAnalyser.Boundary boundary = analyser.new Boundary(10, 15, 1);

        // Update the boundary to include a new point (20, 25).
        boundary.update(20, 25);

        // Verify if the boundaries have been updated correctly.
        assertEquals(10, boundary.minX);
        assertEquals(15, boundary.minY);
        assertEquals(20, boundary.maxX);
        assertEquals(25, boundary.maxY);
        assertEquals(10, boundary.getWidth());
        assertEquals(10, boundary.getHeight());
    }

    /**
     * Test the logic that identifies whether a boundary box is too squashed based on its aspect ratio.
     */
    @Test
    void testSmallOrSquashedBoxFiltering() {
        // Create a new Boundary object starting at position (0, 0) and type 1.
        BloodCellAnalyser.Boundary boundary = analyser.new Boundary(0, 0, 1);

        // Update the boundary to create a squashed rectangle (5,1).
        boundary.update(5, 1);

        // Test if the boundary is correctly identified as being too squashed.
        assertTrue(boundary.isTooSquashed(), "Should be identified as squashed");

        // Update the boundary to make it less squashed (5,5).
        boundary.update(5, 5);

        // Test if the boundary is now correctly identified as not being too squashed.
        assertFalse(boundary.isTooSquashed(), "Should no longer be squashed");
    }
}
