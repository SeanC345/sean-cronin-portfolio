package com.example.ca1bloodanalyser;

import javafx.application.Platform;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.layout.Pane;
import org.openjdk.jmh.annotations.*;

import java.io.InputStream;
import java.util.Arrays;
import java.util.concurrent.TimeUnit;

// Configure the benchmarks to measure average execution time, display results in milliseconds
@BenchmarkMode(Mode.AverageTime)
@OutputTimeUnit(TimeUnit.MILLISECONDS)
@State(Scope.Thread) // Each test thread will use a separate instance of this benchmark class
@Fork(1) // Run one fork to minimize interference from JVM adaptations
@Warmup(iterations = 2, time = 2, timeUnit = TimeUnit.SECONDS) // Prepare the JVM for benchmarking by running some preliminary trials
@Measurement(iterations = 2, time = 2, timeUnit = TimeUnit.SECONDS) // Define how the benchmark trials are measured
public class BloodCellAnalyserBenchmark {

    private BloodCellAnalyser analyser;
    private ImageProcessor imageProcessor;
    private Image testImage;
    private int[] parent; // Union-Find data structure to keep track of connected components
    private int[] colorType; // Array to store the type of each cell based on its color
    private int width; // Width of the test image
    private int height; // Height of the test image
    private Label totalCountLabel;
    private Pane hoverPane;

    // Setup the benchmark environment before each trial
    @Setup(Level.Trial)
    public void setup() {
        // Initialize JavaFX toolkit to handle UI components like Image
        Platform.startup(() -> {});

        analyser = new BloodCellAnalyser();
        imageProcessor = new ImageProcessor();

        // Load an image from resources for testing
        InputStream imageStream = getClass().getResourceAsStream("/com/example/ca1bloodanalyser/bloodcellsample.png");
        if (imageStream == null) {
            throw new RuntimeException("Error loading image: /com/example/ca1bloodanalyser/bloodcellsample.png");
        }
        testImage = new Image(imageStream);

        width = (int) testImage.getWidth();
        height = (int) testImage.getHeight();
        int n = width * height;

        // Initialize arrays for Union-Find algorithm
        parent = new int[n];
        colorType = new int[n];
        Arrays.fill(parent, -1);

        // Create a Label to mimic GUI element where results would be displayed
        totalCountLabel = new Label();

        // Initialize a Pane for displaying image overlays (useful in GUI applications)
        Platform.runLater(() -> hoverPane = new Pane());
    }

    // Benchmark the efficiency of the Find operation in the Union-Find structure
    @Benchmark
    public void benchmarkFind() {
        int index = width * height / 2; // Sample index for testing
        analyser.find(parent, index);
    }

    // Benchmark the efficiency of the Union operation in the Union-Find structure
    @Benchmark
    public void benchmarkUnion() {
        int idx1 = (width * height / 3); // Sample index for testing
        int idx2 = (width * height / 4); // Another sample index for testing
        analyser.union(parent, idx1, idx2);
    }

    // Benchmark the performance of the Hue, Saturation, and Brightness adjustment method
    @Benchmark
    public void benchmarkHueSaturationAdjustment() {
        imageProcessor.applyHueSaturationAdjustment(testImage, 10, 1.2, 0.1);
    }

    // Benchmark the performance of converting an image to a tri-color format for easier cell type identification
    @Benchmark
    public void benchmarkTricolorConversion() {
        imageProcessor.convertToTricolor(testImage, 250);
    }

    // Benchmark the cell detection process
    @Benchmark
    public void benchmarkDetectCells() {
        analyser.detectCells(testImage, 10, totalCountLabel, true, true, true, null, true, 1.0, 1.0);
    }

    // Benchmark the process of drawing bounding boxes around detected cells
    @Benchmark
    public void benchmarkDrawBoundingBoxes() {
        analyser.drawBoundingBoxes(width, height, parent, colorType, totalCountLabel, true, true, true, null, true, 1.0, 1.0);
    }

    // Main method to run benchmarks using the Java Microbenchmark Harness (JMH)
    public static void main(String[] args) throws Exception {
        org.openjdk.jmh.Main.main(args);
    }
}
