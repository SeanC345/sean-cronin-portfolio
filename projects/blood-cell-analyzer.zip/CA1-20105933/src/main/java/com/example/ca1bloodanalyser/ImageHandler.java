package com.example.ca1bloodanalyser;

// Import necessary classes for image handling and file operations.
import javafx.scene.image.Image;
import java.io.File;

public class ImageHandler {

    /**
     * Loads an image from a specified file path.
     * @param file The File object that represents the file to be loaded.
     * @return An Image object that contains the data from the file.
     */
    public Image loadImage(File file) {
        // Convert the File object to a URI and create an Image object.
        // The Image class in JavaFX can directly accept a URI string which points to the image source.
        // This method will throw an IllegalArgumentException if the URL is not valid or the image cannot be loaded.
        return new Image(file.toURI().toString());
    }

}
