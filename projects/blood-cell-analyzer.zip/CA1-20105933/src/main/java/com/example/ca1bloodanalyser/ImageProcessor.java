package com.example.ca1bloodanalyser;

import javafx.scene.image.Image;
import javafx.scene.image.PixelReader;
import javafx.scene.image.PixelWriter;
import javafx.scene.image.WritableImage;
import javafx.scene.paint.Color;

public class ImageProcessor {

    // These are adjustable parameters to fine-tune the color detection ranges
    private double redHueMin = 0;
    private double redHueMax = 50; // Adjusted to better capture red blood cells (RBCs)
    private double purpleHueMin = 220; // Adjusted to include more potential white blood cells (WBCs)
    private double purpleHueMax = 310; // Expanded to ensure a wider range of WBC detection
    private double minSaturation = 0.35; // Increased to reduce false positives in WBC detection
    private double maxBrightness = 0.85; // Slightly darker maximum brightness to accommodate more WBCs
    private Image adjustedOriginalImage; // Holds the image with applied adjustments for hue, saturation, brightness
    private Image tricolourImage; // Stores a version of the image coded in three colors for easy cell type identification

    /**
     * Applies adjustments to hue, saturation, and brightness to an image.
     * @param original The original image to be adjusted.
     * @param hueAdjustment Degree of hue shift applied.
     * @param saturationMultiplier Multiplier for adjusting saturation.
     * @param brightnessAdjustment Adjustment for brightness.
     * @return A new image with the applied adjustments.
     */
    public Image applyHueSaturationAdjustment(Image original, double hueAdjustment, double saturationMultiplier, double brightnessAdjustment) {
        int width = (int) original.getWidth();
        int height = (int) original.getHeight();
        WritableImage adjustedImage = new WritableImage(width, height);
        PixelReader reader = original.getPixelReader();
        PixelWriter writer = adjustedImage.getPixelWriter();

        // Process each pixel to adjust hue, saturation, and brightness
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                Color color = reader.getColor(x, y);
                double newHue = (color.getHue() + hueAdjustment) % 360; // Adjust hue
                if (newHue < 0) {
                    newHue += 360; // Correct negative hue values
                }
                double newSaturation = clamp(color.getSaturation() * saturationMultiplier, 0, 1); // Scale saturation
                double newBrightness = clamp(color.getBrightness() + brightnessAdjustment, 0, 1); // Adjust brightness

                Color adjustedColor = Color.hsb(newHue, newSaturation, newBrightness, color.getOpacity());
                writer.setColor(x, y, adjustedColor);
            }
        }
        return adjustedImage; // Return the modified image
    }

    /**
     * Converts an image to a tri-color version for easier visualization of different cell types.
     * @param image The image to convert.
     * @param wbcHueThreshold The hue threshold around which WBC detection will be centered.
     * @return A new tri-color image highlighting different cell types.
     */
    public Image convertToTricolor(Image image, double wbcHueThreshold) {
        int width = (int) image.getWidth();
        int height = (int) image.getHeight();
        WritableImage triColorImage = new WritableImage(width, height);
        PixelReader reader = image.getPixelReader();
        PixelWriter writer = triColorImage.getPixelWriter();

        // Set dynamic ranges for RBCs and WBCs based on hue threshold
        double redHueMin = 0;
        double redHueMax = 55; // Captures a broad range of red hues
        double purpleHueMin = wbcHueThreshold - 30; // Expands detection range based on a dynamic threshold
        double purpleHueMax = wbcHueThreshold + 30;
        double minSaturation = 0.35; // Minimum saturation for cell detection
        double minBrightness = 0.2; // Minimum brightness for valid cell detection
        double maxBrightness = 0.9; // Maximum brightness threshold for cells

        // Process each pixel to classify it based on color properties
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                Color color = reader.getColor(x, y);
                double hue = color.getHue();
                double saturation = color.getSaturation();
                double brightness = color.getBrightness();

                // Classify and color the pixel based on its properties
                if (brightness > maxBrightness || saturation < minSaturation) {
                    writer.setColor(x, y, Color.WHITE); // Background or non-cellular
                } else if (hue >= redHueMin && hue <= redHueMax) {
                    writer.setColor(x, y, Color.RED); // Red blood cells
                } else if (hue >= purpleHueMin && hue <= purpleHueMax && brightness > minBrightness) {
                    writer.setColor(x, y, Color.PURPLE); // White blood cells
                } else {
                    writer.setColor(x, y, Color.WHITE); // Default to background
                }
            }
        }
        return triColorImage; // Return the color-coded image
    }

    /**
     * Clamps a value to ensure it falls within a specified range.
     * @param value The value to clamp.
     * @param min The minimum allowed value.
     * @param max The maximum allowed value.
     * @return The clamped value.
     */
    public double clamp(double value, double min, double max) {
        return Math.max(min, Math.min(max, value)); // Ensure value is within the bounds
    }

    // Setters to allow GUI adjustments to the color detection parameters
    public void setRedHueRange(double min, double max) {
        this.redHueMin = min;
        this.redHueMax = max;
    }

    public void setPurpleHueRange(double min, double max) {
        this.purpleHueMin = min;
        this.purpleHueMax = max;
    }

    public void setAdjustedImage(Image adjustedImage) {
        this.adjustedOriginalImage = adjustedImage; // Store adjusted image for further use
    }

    public void setTricolourImage(Image tricolour) {
        this.tricolourImage = tricolour; // Store tri-color image separately for visualization
    }
}
