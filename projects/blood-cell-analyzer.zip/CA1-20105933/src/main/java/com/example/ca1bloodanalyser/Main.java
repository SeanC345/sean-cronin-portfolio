package com.example.ca1bloodanalyser;

public class Main {
    public static void main(String[] args) {
        // Launch the JavaFX application using MainController
        MainController.launchApp(args);
    }
}
