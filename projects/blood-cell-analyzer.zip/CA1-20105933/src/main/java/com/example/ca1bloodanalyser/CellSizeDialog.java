package com.example.ca1bloodanalyser;

import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.util.Pair;

import java.util.Optional;

    public class CellSizeDialog {

        private int minCellSize;
        private int maxCellSize;

        public CellSizeDialog(int currentMin, int currentMax) {
            this.minCellSize = currentMin;
            this.maxCellSize = currentMax;
        }

        public Optional<Pair<Integer, Integer>> show() {
            // Create dialog
            Dialog<Pair<Integer, Integer>> dialog = new Dialog<>();
            dialog.setTitle("Cell Size Settings");
            dialog.setHeaderText("Adjust Minimum & Maximum Cell Size");

            // Create input fields
            GridPane grid = new GridPane();
            grid.setHgap(10);
            grid.setVgap(10);

            TextField minSizeField = new TextField(String.valueOf(minCellSize));
            TextField maxSizeField = new TextField(String.valueOf(maxCellSize));

            grid.add(new Label("Min Cell Size:"), 0, 0);
            grid.add(minSizeField, 1, 0);
            grid.add(new Label("Max Cell Size:"), 0, 1);
            grid.add(maxSizeField, 1, 1);

            dialog.getDialogPane().setContent(grid);

            // Add OK and Cancel buttons
            ButtonType applyButton = new ButtonType("Apply", ButtonBar.ButtonData.OK_DONE);
            dialog.getDialogPane().getButtonTypes().addAll(applyButton, ButtonType.CANCEL);

            // Convert result
            dialog.setResultConverter(dialogButton -> {
                if (dialogButton == applyButton) {
                    try {
                        int minSize = Integer.parseInt(minSizeField.getText());
                        int maxSize = Integer.parseInt(maxSizeField.getText());
                        return new Pair<>(minSize, maxSize);
                    } catch (NumberFormatException e) {
                        showErrorAlert("Invalid Input", "Please enter valid numbers.");
                    }
                }
                return null;
            });

            return dialog.showAndWait();
        }

        private void showErrorAlert(String title, String message) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle(title);
            alert.setHeaderText(null);
            alert.setContentText(message);
            alert.showAndWait();
        }
    }

