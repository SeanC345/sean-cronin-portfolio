package com.example.ca1bloodanalyser;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.image.PixelReader;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

public class BloodCellAnalyser {

    // Display the cell detection results in a JavaFX window
    public void displayCellDetection(Image originalImage, Image triColorImage, int cellSize, Label totalCountLabel) {
        Stage stage = new Stage(); // Create a new window (stage) for displaying the results
        stage.setTitle("Detected Blood Cells"); // Set the title of the window

        // Calculate the dimensions for scaling the image to fit the display
        double imageWidth = originalImage.getWidth();
        double imageHeight = originalImage.getHeight();
        double displayWidth = 900; // Desired display width
        double displayHeight = (imageHeight / imageWidth) * displayWidth; // Calculate height maintaining aspect ratio

        double scaleX = displayWidth / imageWidth; // Scaling factor for width
        double scaleY = displayHeight / imageHeight; // Scaling factor for height

        // Setup the ImageView that will show the original image
        ImageView imageView = new ImageView(originalImage);
        imageView.setPreserveRatio(true); // Maintain image aspect ratio
        imageView.setFitWidth(displayWidth); // Set the width to scale
        imageView.setFitHeight(displayHeight); // Set the height to scale

        // Checkboxes to control visibility of different cell types
        CheckBox greenCheckBox = new CheckBox("Show Single RBCs (Green)");
        CheckBox blueCheckBox = new CheckBox("Show RBC Clusters (Blue)");
        CheckBox purpleCheckBox = new CheckBox("Show White Blood Cells (Purple)");
        CheckBox numberingToggle = new CheckBox("Show Sequential Numbering"); // Checkbox for toggling numbering on detected cells

        // Set default selections for checkboxes
        greenCheckBox.setSelected(true);
        blueCheckBox.setSelected(true);
        purpleCheckBox.setSelected(true);
        numberingToggle.setSelected(true);

        // Create a pane to overlay on the image to handle mouse events and additional graphics
        Pane hoverPane = new Pane();
        hoverPane.setPrefSize(displayWidth, displayHeight); // Set the size of the hover pane to match the display size

        // Detect and display cells
        Group detectedGroup = detectCells(triColorImage, cellSize, totalCountLabel,
                true, true, true, hoverPane, numberingToggle.isSelected(), scaleX, scaleY);

        // Scale and position the rectangles (boundaries) based on scaling factors
        for (javafx.scene.Node node : detectedGroup.getChildren()) {
            if (node instanceof Rectangle rect) {
                rect.setX(rect.getX() * scaleX);
                rect.setY(rect.getY() * scaleY);
                rect.setWidth(rect.getWidth() * scaleX);
                rect.setHeight(rect.getHeight() * scaleY);
            }
        }

        StackPane imagePane = new StackPane(imageView, detectedGroup, hoverPane); // Stack pane to layer the image and overlays

        // Button to refresh detection with current checkbox states
        Button refreshButton = new Button("Update Detection");
        refreshButton.setOnAction(e -> {
            boolean showGreen = greenCheckBox.isSelected();
            boolean showBlue = blueCheckBox.isSelected();
            boolean showPurple = purpleCheckBox.isSelected();
            boolean showNumbersNow = numberingToggle.isSelected();

            // Redetect cells based on updated settings
            Group newDetectedGroup = detectCells(triColorImage, cellSize, totalCountLabel,
                    showGreen, showBlue, showPurple, hoverPane, showNumbersNow, scaleX, scaleY);

            // Update the group with new rectangles
            for (javafx.scene.Node node : newDetectedGroup.getChildren()) {
                if (node instanceof Rectangle rect) {
                    rect.setX(rect.getX() * scaleX);
                    rect.setY(rect.getY() * scaleY);
                    rect.setWidth(rect.getWidth() * scaleX);
                    rect.setHeight(rect.getHeight() * scaleY);
                }
            }

            // Clear old detected groups and add the new one
            imagePane.getChildren().removeIf(n -> n instanceof Group);
            imagePane.getChildren().add(newDetectedGroup);
        });

        // Layout for the control toggles
        VBox toggleControls = new VBox(5, greenCheckBox, blueCheckBox, purpleCheckBox, numberingToggle, refreshButton);
        toggleControls.setAlignment(Pos.CENTER);
        toggleControls.setPadding(new Insets(5));

        // Assuming you have a layout manager that directly contains all the components
        VBox contentBox = new VBox(imagePane, toggleControls);
        contentBox.setSpacing(10);  // Ensure there's some spacing if needed

        ScrollPane scrollPane = new ScrollPane();
        scrollPane.setContent(contentBox);
        scrollPane.setFitToWidth(true);  // Fit the content width to the width of the scroll pane
        scrollPane.setVbarPolicy(ScrollPane.ScrollBarPolicy.AS_NEEDED);
        scrollPane.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);  // Assuming horizontal scrolling isn't needed

        // Set the scene with all controls and the image display
        Scene detectionScene = new Scene(scrollPane, 700, 700);
        stage.setScene(detectionScene);
        stage.setResizable(true); // Allow window resizing
        stage.show(); // Display the window
    }

    // Method to detect cells in an image based on color and brightness characteristics
    public Group detectCells(Image adjustedImage, int cellSize, Label totalCountLabel, boolean showGreen, boolean showBlue, boolean showPurple, Pane hoverPane, boolean showNumbers, double scaleX, double scaleY ) {
        int width = (int) adjustedImage.getWidth();
        int height = (int) adjustedImage.getHeight();
        int n = width * height; // Total number of pixels

        int[] parent = new int[n]; // Array for Union-Find algorithm to track connected components
        int[] colorType = new int[n]; // Array to store the type of each cell detected based on color

        Arrays.fill(parent, -1); // Initialize the parent array for union-find

        if (hoverPane == null) {
            hoverPane = new Pane();  // Create a temporary pane if none provided
        }

        PixelReader pr = adjustedImage.getPixelReader(); // Get a pixel reader for the image
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                int idx = y * width + x;
                Color color = pr.getColor(x, y);
                double hue = color.getHue();
                double saturation = color.getSaturation();

                // Classify cells based on color hue and saturation
                if ((hue < 20 || hue > 340) && saturation > 0.4) {
                    colorType[idx] = 1; //  Red Blood Cell
                } else if (hue > 180 && hue < 310 && saturation > 0.2) {
                    colorType[idx] = 2; //  White Blood Cell
                } else {
                    colorType[idx] = 0; //  Background (ignored)
                }
            }
        }

        // Union-Find clustering to group connected components of the same type
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                int idx = y * width + x;
                if (colorType[idx] == 0) continue;

                // Union adjacent cells of the same type if their brightness difference is small
                if (x + 1 < width) {
                    int idxRight = y * width + (x + 1);
                    if (colorType[idxRight] == colorType[idx]) {
                        if (Math.abs(pr.getColor(x, y).getBrightness() - pr.getColor(x + 1, y).getBrightness()) < 0.2) {
                            union(parent, idx, idxRight);
                        }
                    }
                }

                if (y + 1 < height) {
                    int idxBottom = (y + 1) * width + x;
                    if (colorType[idxBottom] == colorType[idx]) {
                        if (Math.abs(pr.getColor(x, y).getBrightness() - pr.getColor(x, y + 1).getBrightness()) < 0.2) {
                            union(parent, idx, idxBottom);
                        }
                    }
                }
            }
        }

        // Draw bounding boxes around detected cells based on the union-find result
        return drawBoundingBoxes(width, height, parent, colorType, totalCountLabel, showGreen, showBlue, showPurple, hoverPane, showNumbers, scaleX, scaleY);
    }

    // Helper class for representing cell boundaries
    public class Boundary {
        int minX, minY, maxX, maxY, count, type; // Boundary box coordinates, count of pixels in the box, and cell type
        int id; // Unique identifier for the boundary
        AtomicBoolean isTooltipVisible = new AtomicBoolean(false); // Toggle for displaying tooltip on hover

        public Boundary(int x, int y, int type) {
            this.minX = this.maxX = x; // Initialize min and max X
            this.minY = this.maxY = y; // Initialize min and max Y
            this.count = 1; // Start with one pixel
            this.type = type; // Cell type (RBC, WBC, etc.)
        }

        // Update boundary to include a new pixel
        public void update(int x, int y) {
            minX = Math.min(minX, x);
            maxX = Math.max(maxX, x);
            minY = Math.min(minY, y);
            maxY = Math.max(maxY, y);
            count++; // Increment pixel count
        }

        // Get the width of the boundary
        public int getWidth() { return maxX - minX; }
        // Get the height of the boundary
        public int getHeight() { return maxY - minY; }
        // Check if the boundary box is too small
        public boolean isTooSmall(int minSize) { return getWidth() < minSize || getHeight() < minSize; }
        // Check if the boundary box is disproportionately stretched
        public boolean isTooSquashed() {
            double aspectRatio = (double) getWidth() / getHeight();
            return aspectRatio < 0.3 || aspectRatio > 3.0;
        }
    }

    // Draw bounding boxes around detected cells
    public Group drawBoundingBoxes(int width, int height, int[] parent, int[] colorType, Label totalCountLabel,
                                   boolean showGreen, boolean showBlue, boolean showPurple, Pane hoverPane, boolean showNumbers, double scaleX, double scaleY) {

        Map<Integer, Boundary> boundaries = new HashMap<>(); // Map to store boundaries identified by their root index
        int totalRBCs = 0; // Total count of red blood cells
        int totalWBCs = 0; // Total count of white blood cells
        double avgCellArea = 300; // Average area of a cell, used for estimating cell counts in clusters

        // Identify boundaries for each connected component
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                int idx = y * width + x;
                if (colorType[idx] == 0) continue; // Skip background
                int root = find(parent, idx); // Find the root of the current pixel's set
                int finalX = x;
                int finalY = y;
                boundaries.computeIfAbsent(root, k -> new Boundary(finalX, finalY, colorType[idx])).update(x, y); // Update or create new boundary for this root
            }
        }

        List<Boundary> boundaryList = new ArrayList<>(boundaries.values()); // Convert map to list for easier manipulation

        // Remove small and disproportionately stretched boundaries
        int minSizeThreshold = 10; // Minimum size threshold for a boundary to be considered
        boundaryList.removeIf(b -> b.isTooSmall(minSizeThreshold) || b.isTooSquashed());

        // Sort boundaries by their top-left corner for structured display and processing
        boundaryList.sort(Comparator.comparingInt(b -> b.minY * width + b.minX));

        // Assign sequential numbering to each boundary for identification
        AtomicInteger sequentialCounter = new AtomicInteger(1);
        for (Boundary b : boundaryList) {
            b.id = sequentialCounter.getAndIncrement();
        }

        Group group = new Group(); // Create a group to hold all drawing elements

        // Iterate over each boundary to create rectangles and tooltips
        for (Boundary b : boundaryList) {
            int boxWidth = b.getWidth();
            int boxHeight = b.getHeight();
            int area = boxWidth * boxHeight; // Calculate the area of the boundary

            Rectangle rect = new Rectangle(b.minX, b.minY, boxWidth, boxHeight); // Create a rectangle for this boundary
            rect.setFill(Color.TRANSPARENT); // Set the fill to transparent
            rect.setStrokeWidth(2); // Set the stroke width

            int estimatedCells = (int) Math.round(area / avgCellArea); // Estimate the number of cells within this boundary
            if (estimatedCells < 1) estimatedCells = 1; // Ensure there's at least one cell counted

            if (b.type == 1) { // If the boundary is for RBCs
                if (area < avgCellArea) {
                    if (showGreen) rect.setStroke(Color.GREEN); // Use green for single RBCs
                    estimatedCells = 1;
                } else {
                    if (showBlue) rect.setStroke(Color.BLUE); // Use blue for RBC clusters
                }
                totalRBCs += estimatedCells; // Update total RBC count
            } else { // If the boundary is for WBCs
                if (showPurple) {
                    rect.setStroke(Color.PURPLE); // Use purple for WBCs
                    rect.setStrokeWidth(3); // Make the stroke wider for visibility
                }
                totalWBCs++; // Update total WBC count
            }

            // Tooltip for showing estimated cell count on click
            Label tooltipLabel = new Label("Estimated blood cells: " + estimatedCells);
            tooltipLabel.setStyle("-fx-background-color: black; -fx-text-fill: white; -fx-padding: 5px; -fx-font-size: 12px;");
            tooltipLabel.setVisible(false); // Initially hide the tooltip

            // Show or hide the tooltip on mouse click
            rect.setOnMouseClicked(event -> {
                boolean currentlyVisible = b.isTooltipVisible.get();
                b.isTooltipVisible.set(!currentlyVisible);
                tooltipLabel.setVisible(!currentlyVisible);

                if (!currentlyVisible) {
                    tooltipLabel.setLayoutX(event.getSceneX() + 10); // Position tooltip near the mouse cursor
                    tooltipLabel.setLayoutY(event.getSceneY() - 10);
                }
            });

            hoverPane.getChildren().add(tooltipLabel); // Add tooltip to the hover pane
            group.getChildren().add(rect); // Add the rectangle to the group

            // Add numbering label if toggled
            if (showNumbers) {
                Label numberLabel = new Label(String.valueOf(b.id)); // Create a label with the boundary's number
                numberLabel.setStyle("-fx-background-color: white; -fx-text-fill: black; -fx-font-weight: bold; -fx-padding: 2px; -fx-border-color: black;");

                // Scale coordinates for number labels
                numberLabel.setLayoutX(b.minX * scaleX + 2); // Position label at the bottom-left of the rectangle
                numberLabel.setLayoutY(b.maxY * scaleY - 5);
                numberLabel.toFront(); // Ensure the label is visible on top of other elements

                group.getChildren().add(numberLabel); // Add the number label to the group
            }
        }

        // Update the total count label with the number of RBCs and WBCs detected
        totalCountLabel.setText(" RBCs: " + totalRBCs + "    WBCs: " + totalWBCs);
        totalCountLabel.setStyle("-fx-font-size: 16px; -fx-font-weight: bold; -fx-padding: 10px;");

        return group; // Return the group containing all drawing elements
    }

    // Find the root of the set containing the element at index i
    public int find(int[] parent, int i) {
        if (parent[i] < 0) {
            return i; // Return the root if found
        }
        return parent[i] = find(parent, parent[i]); // Path compression
    }

    // Union two sets containing elements p and q
    public void union(int[] parent, int p, int q) {
        int rootP = find(parent, p); // Find the root of p
        int rootQ = find(parent, q); // Find the root of q
        if (rootP == rootQ) return; // They are already in the same set

        // Weighted union
        if (parent[rootP] < parent[rootQ]) {
            parent[rootP] += parent[rootQ]; // Add size of set q to set p
            parent[rootQ] = rootP; // Make p the root of q
        } else {
            parent[rootQ] += parent[rootP]; // Add size of set p to set q
            parent[rootP] = rootQ; // Make q the root of p
        }
    }
}
