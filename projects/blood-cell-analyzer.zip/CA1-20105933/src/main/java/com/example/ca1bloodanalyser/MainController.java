package com.example.ca1bloodanalyser;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.File;

public class MainController extends Application {

    private ImageHandler imageHandler; // Handles image loading
    private ImageProcessor imageProcessing; // Handles image processing
    private BloodCellAnalyser bloodCellAnalyser; // Analyzes blood cells

    private ImageView originalImageView, processedImageView; // Image views for original and processed images
    private Image originalImage, adjustedImage, adjustedTriColorImage; // Images used for processing
    private Pane overlayPane; // Overlay pane for bounding boxes

    private Slider hueSlider, saturationSlider, brightnessSlider, wbcHueSlider; // UI sliders for adjustments
    private Label totalCountLabel; // Displays the count of detected blood cells

    private static final double DEFAULT_HUE = 0;
    private static final double DEFAULT_SATURATION = 1;
    private static final double DEFAULT_BRIGHTNESS = 0;

    public static void launchApp(String[] args) {
        launch(args); // Start the JavaFX application
    }

    @Override
    public void start(Stage primaryStage) {
        imageHandler = new ImageHandler(); // Initialize image handler
        imageProcessing = new ImageProcessor(); // Initialize image processor
        bloodCellAnalyser = new BloodCellAnalyser(); // Initialize blood cell analyser

        totalCountLabel = new Label("RBCs: 0   WBCs: 0"); // Initial label setup
        totalCountLabel.setStyle("-fx-font-size: 16px; -fx-font-weight: bold; -fx-padding: 10px;");

        // Menu Bar for file selection
        MenuBar menuBar = new MenuBar();
        Menu fileMenu = new Menu("File");
        MenuItem openItem = new MenuItem("Open Image");
        openItem.setOnAction(e -> openImage(primaryStage)); // Opens image when clicked
        fileMenu.getItems().add(openItem);
        // Create Exit menu item
        MenuItem exitItem = new MenuItem("Exit");
        exitItem.setOnAction(e -> Platform.exit()); // Action to exit application
        fileMenu.getItems().add(exitItem); // Add exit item to file menu
        menuBar.getMenus().add(fileMenu);


        // Image Views Setup
        originalImageView = new ImageView();
        originalImageView.setPreserveRatio(true);
        originalImageView.setFitHeight(400);

        processedImageView = new ImageView();
        processedImageView.setPreserveRatio(true);
        processedImageView.setFitHeight(400);

        overlayPane = new Pane(); // Pane for bounding boxes
        overlayPane.setPickOnBounds(false); // Allow interaction through the overlay

        StackPane processedImageStack = new StackPane(processedImageView, overlayPane);
        processedImageStack.setAlignment(Pos.CENTER);

        // Organize images in a SplitPane
        SplitPane imagePane = new SplitPane(new StackPane(originalImageView), processedImageStack);
        imagePane.setDividerPositions(0.5);
        imagePane.setMinHeight(420);
        imagePane.setMaxHeight(420);
        imagePane.setPadding(new Insets(5));

        // Adjustment Sliders
        hueSlider = createSlider(-180, 180, DEFAULT_HUE);
        saturationSlider = createSlider(0, 2, DEFAULT_SATURATION);
        brightnessSlider = createSlider(-1, 1, DEFAULT_BRIGHTNESS);

        hueSlider.valueProperty().addListener((obs, oldVal, newVal) -> updateOriginalImage());
        saturationSlider.valueProperty().addListener((obs, oldVal, newVal) -> updateOriginalImage());
        brightnessSlider.valueProperty().addListener((obs, oldVal, newVal) -> updateOriginalImage());

        // WBC Hue Threshold Slider
        wbcHueSlider = createSlider(200, 310, 255);
        wbcHueSlider.valueProperty().addListener((obs, oldVal, newVal) -> updateProcessedImage());

        // Organize Adjustment Controls
        VBox adjustmentBox = new VBox(5,
                new Label("Adjust Original Image"),
                new Label("Adjust Hue"), hueSlider,
                new Label("Adjust Saturation"), saturationSlider,
                new Label("Adjust Brightness"), brightnessSlider,
                new Label("WBC Hue Threshold"), wbcHueSlider);
        adjustmentBox.setAlignment(Pos.CENTER);
        adjustmentBox.setPadding(new Insets(5));

        // Buttons for Tri-Color Filter & Detection
        Button applyTriColorButton = new Button("Apply Tri-Color Filter");
        applyTriColorButton.setOnAction(e -> updateProcessedImage());

        Button detectCellsButton = new Button("Detect Cells");
        detectCellsButton.setOnAction(e -> detectCells());

        Button resetButton = new Button("Reset Settings");
        resetButton.setOnAction(e -> resetSliders());

        VBox buttonControls = new VBox(5, applyTriColorButton, detectCellsButton, resetButton);
        buttonControls.setAlignment(Pos.CENTER);
        buttonControls.setPadding(new Insets(5));

        // Label for Total Count
        VBox labelContainer = new VBox(totalCountLabel);
        labelContainer.setAlignment(Pos.CENTER);

        // Root Layout
        VBox root = new VBox(5, menuBar, imagePane, labelContainer, adjustmentBox, buttonControls);
        root.setPadding(new Insets(5));

        // Wrap Everything in a ScrollPane
        ScrollPane scrollPane = new ScrollPane();
        scrollPane.setContent(root);
        scrollPane.setFitToWidth(true);
        scrollPane.setFitToHeight(false);
        scrollPane.setVbarPolicy(ScrollPane.ScrollBarPolicy.AS_NEEDED);
        scrollPane.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);

        // Set Scene & Show Window
        Scene scene = new Scene(scrollPane, 800, 700);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Blood Cell Analyser");
        primaryStage.show();
    }

    private Slider createSlider(double min, double max, double initial) {
        Slider slider = new Slider(min, max, initial);
        slider.setShowTickLabels(true);
        slider.setShowTickMarks(true);
        slider.setMajorTickUnit((max - min) / 4);
        slider.setBlockIncrement(1);
        return slider;
    }

    private void openImage(Stage stage) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Open Blood Sample Image");
        File file = fileChooser.showOpenDialog(stage);
        if (file != null) {
            originalImage = imageHandler.loadImage(file);
            originalImageView.setImage(originalImage);
        }
    }

    private void updateOriginalImage() {
        if (originalImage != null) {
            adjustedImage = imageProcessing.applyHueSaturationAdjustment(originalImage, hueSlider.getValue(), saturationSlider.getValue(), brightnessSlider.getValue());
            imageProcessing.setAdjustedImage(adjustedImage); // Store adjusted image
            originalImageView.setImage(adjustedImage);
        }
    }

    private void updateProcessedImage() {
        if (adjustedImage != null) {
            double wbcHueThreshold = wbcHueSlider.getValue();

            // Convert image with updated WBC hue
            adjustedTriColorImage = imageProcessing.convertToTricolor(adjustedImage, wbcHueThreshold);

            // Store & display the updated tri-color image
            imageProcessing.setTricolourImage(adjustedTriColorImage);
            processedImageView.setImage(adjustedTriColorImage);
        }
    }

    private void detectCells() {
        if (adjustedImage != null) {
            adjustedTriColorImage = imageProcessing.convertToTricolor(adjustedImage, wbcHueSlider.getValue());
            imageProcessing.setTricolourImage(adjustedTriColorImage);
            processedImageView.setImage(adjustedTriColorImage);

            bloodCellAnalyser.displayCellDetection(adjustedImage, adjustedTriColorImage, 15, totalCountLabel);
        }
    }

    private void resetSliders() {
        hueSlider.setValue(DEFAULT_HUE);
        saturationSlider.setValue(DEFAULT_SATURATION);
        brightnessSlider.setValue(DEFAULT_BRIGHTNESS);
    }
}
