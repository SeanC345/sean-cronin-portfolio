module com.example.ca1bloodanalyser {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.desktop;
    requires jmh.core;

    opens com.example.ca1bloodanalyser to javafx.fxml, jmh.core;
    exports com.example.ca1bloodanalyser;
}
